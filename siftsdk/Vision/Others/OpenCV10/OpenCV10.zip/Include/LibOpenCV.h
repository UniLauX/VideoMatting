#pragma once

//#ifdef _DEBUG
#pragma comment(lib, "Z:\\OpenCV10\\lib\\cv.lib")
#pragma comment(lib, "Z:\\OpenCV10\\lib\\highgui.lib")
//#else
//#pragma comment(lib, "Z:\\OpenCV10\\lib\\cv.lib")
//#pragma comment(lib, "Z:\\OpenCV10\\lib\\highgui.lib")
//#endif